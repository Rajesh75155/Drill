package com.microservices.personaldetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaldetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
