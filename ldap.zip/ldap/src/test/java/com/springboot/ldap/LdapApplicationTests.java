package com.springboot.ldap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapApplicationTests {

	@Test
	void contextLoads() {
	}

}
