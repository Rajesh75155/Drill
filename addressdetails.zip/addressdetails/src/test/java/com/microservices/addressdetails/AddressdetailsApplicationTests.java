package com.microservices.addressdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressdetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
